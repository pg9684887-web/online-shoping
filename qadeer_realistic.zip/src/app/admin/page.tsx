"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { AISLE_RACKS, CATEGORIES } from "@/lib/racks";
import type { GameProduct } from "@/lib/types";

const EMPTY = {
  name: "",
  category: "staples",
  price: 0,
  emoji: "🛒",
  color: "#f59e0b",
  imageUrl: "" as string | null,
  modelUrl: "" as string | null,
  rack: 0,
  slot: 0,
};

type Form = typeof EMPTY;

export default function AdminPage() {
  const [products, setProducts] = useState<GameProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<Form>({ ...EMPTY });
  const [editingId, setEditingId] = useState<number | null>(null);
  const [selectedRack, setSelectedRack] = useState(0);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/products");
    const data = await res.json();
    setProducts(data.products ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const rack = AISLE_RACKS[selectedRack];
  const rackProducts = useMemo(
    () => products.filter((p) => p.rack === selectedRack).sort((a, b) => a.slot - b.slot),
    [products, selectedRack]
  );
  const occupiedSlots = useMemo(() => {
    const map = new Map<number, GameProduct>();
    rackProducts.forEach((p) => {
      if (p.id !== editingId) map.set(p.slot, p);
    });
    return map;
  }, [rackProducts, editingId]);

  const resetForm = () => {
    setForm({ ...EMPTY, rack: selectedRack, category: AISLE_RACKS[selectedRack].category });
    setEditingId(null);
    if (fileRef.current) fileRef.current.value = "";
  };

  const startEdit = (p: GameProduct) => {
    setForm({
      name: p.name,
      category: p.category,
      price: p.price,
      emoji: p.emoji,
      color: p.color,
      imageUrl: p.imageUrl ?? "",
      modelUrl: p.modelUrl ?? "",
      rack: p.rack,
      slot: p.slot,
    });
    setSelectedRack(p.rack);
    setEditingId(p.id);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 1_500_000) {
      setMsg("⚠ Image too large (max ~1.5MB). Use a URL instead.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setForm((f) => ({ ...f, imageUrl: String(reader.result) }));
    reader.readAsDataURL(file);
  };

  const submit = async () => {
    if (!form.name.trim()) {
      setMsg("⚠ Product name is required");
      return;
    }
    setBusy(true);
    setMsg("");
    const payload = { ...form, rack: selectedRack };
    try {
      const url = editingId ? `/api/products/${editingId}` : "/api/products";
      const method = editingId ? "PATCH" : "POST";
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      setMsg(editingId ? "✓ Product updated" : "✓ Product added to rack");
      resetForm();
      await load();
    } catch (err) {
      setMsg("⚠ " + String(err));
    } finally {
      setBusy(false);
    }
  };

  const remove = async (id: number) => {
    setBusy(true);
    await fetch(`/api/products/${id}`, { method: "DELETE" });
    if (editingId === id) resetForm();
    await load();
    setBusy(false);
  };

  const reseed = async () => {
    if (!confirm("Reset the entire mart to the default catalogue? This deletes all current products.")) return;
    setBusy(true);
    await fetch("/api/seed?force=1", { method: "POST" });
    await load();
    setBusy(false);
    setMsg("✓ Mart reset to default catalogue");
  };

  return (
    <main className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 text-white">
      <div className="mx-auto max-w-6xl px-4 py-6">
        <header className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h1 className="text-2xl font-black text-emerald-300">🛠 Mart Manager</h1>
            <p className="text-sm text-slate-400">List products, place them on racks, and attach photos or 3D models.</p>
          </div>
          <div className="flex gap-2">
            <button onClick={reseed} className="rounded-xl bg-white/10 px-4 py-2 text-sm font-bold hover:bg-white/20">
              ↻ Reset Catalogue
            </button>
            <Link href="/" className="rounded-xl bg-emerald-500 px-4 py-2 text-sm font-black text-slate-900 hover:bg-emerald-400">
              ▶ Play Game
            </Link>
          </div>
        </header>

        <div className="grid gap-6 lg:grid-cols-[1fr_1.1fr]">
          {/* FORM */}
          <section className="rounded-3xl bg-white/5 p-5 ring-1 ring-white/10">
            <h2 className="mb-4 text-lg font-black">{editingId ? "✏️ Edit Product" : "➕ Add Product"}</h2>

            <label className="mb-3 block">
              <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-400">Product Name</span>
              <input
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="e.g. Tapal Danedar Chai 1kg"
                className="w-full rounded-xl bg-black/40 px-3 py-2 outline-none focus:ring-2 focus:ring-emerald-400"
              />
            </label>

            <div className="mb-3 grid grid-cols-3 gap-3">
              <label className="block">
                <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-400">Price (PKR)</span>
                <input
                  type="number"
                  value={form.price}
                  onChange={(e) => setForm({ ...form, price: Number(e.target.value) })}
                  className="w-full rounded-xl bg-black/40 px-3 py-2 outline-none focus:ring-2 focus:ring-emerald-400"
                />
              </label>
              <label className="block">
                <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-400">Emoji</span>
                <input
                  value={form.emoji}
                  onChange={(e) => setForm({ ...form, emoji: e.target.value })}
                  className="w-full rounded-xl bg-black/40 px-3 py-2 text-center text-xl outline-none focus:ring-2 focus:ring-emerald-400"
                />
              </label>
              <label className="block">
                <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-400">Color</span>
                <input
                  type="color"
                  value={form.color}
                  onChange={(e) => setForm({ ...form, color: e.target.value })}
                  className="h-[42px] w-full rounded-xl bg-black/40 outline-none"
                />
              </label>
            </div>

            <label className="mb-3 block">
              <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-400">Category</span>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="w-full rounded-xl bg-black/40 px-3 py-2 outline-none focus:ring-2 focus:ring-emerald-400"
              >
                {CATEGORIES.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.emoji} {c.label}
                  </option>
                ))}
              </select>
            </label>

            <div className="mb-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <label className="block">
                <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-400">Photo URL / Upload</span>
                <input
                  value={form.imageUrl ?? ""}
                  onChange={(e) => setForm({ ...form, imageUrl: e.target.value })}
                  placeholder="https://…"
                  className="mb-2 w-full rounded-xl bg-black/40 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-400"
                />
                <input ref={fileRef} type="file" accept="image/*" onChange={onFile} className="w-full text-xs text-slate-400 file:mr-2 file:rounded-lg file:border-0 file:bg-emerald-500 file:px-3 file:py-1.5 file:font-bold file:text-slate-900" />
              </label>
              <label className="block">
                <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-400">3D Model URL (.glb)</span>
                <input
                  value={form.modelUrl ?? ""}
                  onChange={(e) => setForm({ ...form, modelUrl: e.target.value })}
                  placeholder="https://…/model.glb"
                  className="w-full rounded-xl bg-black/40 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-emerald-400"
                />
                {form.imageUrl && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={form.imageUrl} alt="preview" className="mt-2 h-20 w-20 rounded-lg object-cover ring-1 ring-white/20" />
                )}
              </label>
            </div>

            {/* Rack + slot picker */}
            <div className="mb-3">
              <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-400">Rack Placement</span>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {AISLE_RACKS.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => {
                      setSelectedRack(r.id);
                      setForm((f) => ({ ...f, rack: r.id }));
                    }}
                    className={`rounded-xl px-2 py-2 text-left text-xs font-bold transition ${
                      selectedRack === r.id ? "bg-emerald-500 text-slate-900" : "bg-black/40 text-slate-200 hover:bg-black/60"
                    }`}
                  >
                    <div className="text-base">{r.emoji}</div>
                    {r.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="mb-4">
              <span className="mb-1 block text-xs font-bold uppercase tracking-wider text-slate-400">
                Shelf Slot on “{rack.label}”
              </span>
              <div className="grid grid-cols-6 gap-2">
                {Array.from({ length: rack.slots }).map((_, i) => {
                  const taken = occupiedSlots.get(i);
                  const active = form.slot === i;
                  return (
                    <button
                      key={i}
                      onClick={() => setForm({ ...form, slot: i })}
                      title={taken ? `Occupied by ${taken.name}` : `Slot ${i + 1}`}
                      className={`relative flex h-14 flex-col items-center justify-center rounded-xl text-xs font-bold ring-1 transition ${
                        active
                          ? "bg-emerald-500 text-slate-900 ring-emerald-300"
                          : taken
                          ? "bg-amber-500/20 text-amber-200 ring-amber-500/40"
                          : "bg-black/40 text-slate-300 ring-white/10 hover:bg-black/60"
                      }`}
                    >
                      <span className="text-lg">{taken ? taken.emoji : i + 1}</span>
                      <span className="text-[9px] opacity-80">{i < 3 ? "front" : "back"}</span>
                    </button>
                  );
                })}
              </div>
              <p className="mt-1 text-[11px] text-slate-500">Slots 1–3 face the front aisle, 4–6 face the back. Amber = occupied.</p>
            </div>

            {msg && <div className="mb-3 rounded-lg bg-black/40 px-3 py-2 text-sm">{msg}</div>}

            <div className="flex gap-2">
              <button
                onClick={submit}
                disabled={busy}
                className="flex-1 rounded-xl bg-gradient-to-r from-emerald-500 to-lime-500 px-4 py-3 font-black text-slate-900 disabled:opacity-50"
              >
                {editingId ? "Save Changes" : "Add to Rack"}
              </button>
              {editingId && (
                <button onClick={resetForm} className="rounded-xl bg-white/10 px-4 py-3 font-bold hover:bg-white/20">
                  Cancel
                </button>
              )}
            </div>
          </section>

          {/* RACK VIEW / PRODUCT LIST */}
          <section className="rounded-3xl bg-white/5 p-5 ring-1 ring-white/10">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-black">
                {rack.emoji} {rack.label}
              </h2>
              <span className="text-xs text-slate-400">{rackProducts.length}/{rack.slots} filled · {products.length} total</span>
            </div>

            {loading ? (
              <div className="py-12 text-center text-slate-400">Loading…</div>
            ) : rackProducts.length === 0 ? (
              <div className="py-12 text-center text-slate-400">No products on this rack yet. Add one on the left! 👈</div>
            ) : (
              <div className="flex flex-col gap-2">
                {rackProducts.map((p) => (
                  <div key={p.id} className="flex items-center gap-3 rounded-xl bg-black/30 p-3 ring-1 ring-white/5">
                    <div className="flex h-11 w-11 items-center justify-center rounded-lg text-2xl" style={{ background: p.color }}>
                      {p.imageUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={p.imageUrl} alt={p.name} className="h-full w-full rounded-lg object-cover" />
                      ) : (
                        p.emoji
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate font-bold">{p.name}</div>
                      <div className="text-xs text-slate-400">
                        Slot {p.slot + 1} · Rs {Math.round(p.price)} {p.modelUrl ? "· 🧊 3D" : ""}
                      </div>
                    </div>
                    <button onClick={() => startEdit(p)} className="rounded-lg bg-white/10 px-3 py-1.5 text-xs font-bold hover:bg-white/20">
                      Edit
                    </button>
                    <button onClick={() => remove(p.id)} className="rounded-lg bg-red-500/20 px-3 py-1.5 text-xs font-bold text-red-300 hover:bg-red-500/40">
                      Delete
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="mt-5">
              <h3 className="mb-2 text-sm font-black text-slate-300">All Racks</h3>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                {AISLE_RACKS.map((r) => {
                  const count = products.filter((p) => p.rack === r.id).length;
                  return (
                    <button
                      key={r.id}
                      onClick={() => setSelectedRack(r.id)}
                      className={`rounded-xl p-2 text-left text-xs ring-1 transition ${
                        selectedRack === r.id ? "bg-emerald-500/20 ring-emerald-400" : "bg-black/30 ring-white/5 hover:bg-black/50"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-base">{r.emoji}</span>
                        <span className="font-black text-emerald-300">{count}/{r.slots}</span>
                      </div>
                      <div className="mt-1 truncate font-semibold text-slate-200">{r.label}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          </section>
        </div>
      </div>
    </main>
  );
}
