import { db } from "@/db";
import { products } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function PATCH(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const pid = Number(id);
    const body = await request.json();
    const patch: Record<string, unknown> = {};
    if (body.name !== undefined) patch.name = String(body.name);
    if (body.category !== undefined) patch.category = String(body.category);
    if (body.price !== undefined) patch.price = Number(body.price);
    if (body.emoji !== undefined) patch.emoji = String(body.emoji).slice(0, 8);
    if (body.color !== undefined) patch.color = String(body.color);
    if (body.imageUrl !== undefined) patch.imageUrl = body.imageUrl ? String(body.imageUrl) : null;
    if (body.modelUrl !== undefined) patch.modelUrl = body.modelUrl ? String(body.modelUrl) : null;
    if (body.rack !== undefined) patch.rack = Number(body.rack);
    if (body.slot !== undefined) patch.slot = Number(body.slot);

    const [row] = await db.update(products).set(patch).where(eq(products.id, pid)).returning();
    return Response.json({ product: row });
  } catch (err) {
    return Response.json({ error: String(err) }, { status: 500 });
  }
}

export async function DELETE(_request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    await db.delete(products).where(eq(products.id, Number(id)));
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: String(err) }, { status: 500 });
  }
}
