import { db } from "@/db";
import { products } from "@/db/schema";
import { asc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(products).orderBy(asc(products.rack), asc(products.slot));
    return Response.json({ products: rows });
  } catch (err) {
    return Response.json({ products: [], error: String(err) }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = String(body.name ?? "").trim();
    if (!name) {
      return Response.json({ error: "Name is required" }, { status: 400 });
    }
    const [row] = await db
      .insert(products)
      .values({
        name,
        category: String(body.category ?? "staples"),
        price: Number(body.price ?? 0),
        emoji: String(body.emoji ?? "🛒").slice(0, 8),
        color: String(body.color ?? "#f59e0b"),
        imageUrl: body.imageUrl ? String(body.imageUrl) : null,
        modelUrl: body.modelUrl ? String(body.modelUrl) : null,
        rack: Number.isFinite(Number(body.rack)) ? Number(body.rack) : 0,
        slot: Number.isFinite(Number(body.slot)) ? Number(body.slot) : 0,
      })
      .returning();
    return Response.json({ product: row });
  } catch (err) {
    return Response.json({ error: String(err) }, { status: 500 });
  }
}
