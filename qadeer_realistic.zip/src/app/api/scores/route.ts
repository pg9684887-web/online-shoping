import { db } from "@/db";
import { highScores } from "@/db/schema";
import { desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(highScores).orderBy(desc(highScores.score)).limit(10);
    return Response.json({ scores: rows });
  } catch (err) {
    return Response.json({ scores: [], error: String(err) }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const [row] = await db
      .insert(highScores)
      .values({
        name: String(body.name ?? "Shopper").slice(0, 40) || "Shopper",
        score: Math.max(0, Math.round(Number(body.score ?? 0))),
        items: Math.max(0, Math.round(Number(body.items ?? 0))),
        spend: Math.max(0, Number(body.spend ?? 0)),
      })
      .returning();
    const rows = await db.select().from(highScores).orderBy(desc(highScores.score)).limit(10);
    return Response.json({ score: row, scores: rows });
  } catch (err) {
    return Response.json({ error: String(err) }, { status: 500 });
  }
}
