import { db } from "@/db";
import { products } from "@/db/schema";
import { SEED_PRODUCTS } from "@/lib/seedProducts";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

// Seeds the mart with the starter catalogue when it is empty. Idempotent-ish:
// only inserts when there are no products yet, unless ?force=1 is passed.
export async function POST(request: Request) {
  try {
    const force = new URL(request.url).searchParams.get("force") === "1";
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(products);

    if (Number(count) > 0 && !force) {
      return Response.json({ seeded: false, count: Number(count) });
    }
    if (force) {
      await db.delete(products);
    }
    await db.insert(products).values(SEED_PRODUCTS);
    return Response.json({ seeded: true, inserted: SEED_PRODUCTS.length });
  } catch (err) {
    return Response.json({ error: String(err) }, { status: 500 });
  }
}
