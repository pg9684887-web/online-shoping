import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Mart Dash — 3D Shopping Simulator 🇵🇰",
  description: "A juicy first-person 3D shopping game set in a Pakistani super store. Grab a cart, fill your list, and dash to checkout!",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#0b1220",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-[#0b1220] text-white antialiased overscroll-none">{children}</body>
    </html>
  );
}
