import { db } from "@/db";
import { products as productsTable, highScores } from "@/db/schema";
import { asc, desc } from "drizzle-orm";
import { SEED_PRODUCTS } from "@/lib/seedProducts";
import Game from "@/components/Game";
import type { GameProduct, ScoreRow } from "@/lib/types";

export const dynamic = "force-dynamic";

async function loadProducts(): Promise<GameProduct[]> {
  let rows = await db.select().from(productsTable).orderBy(asc(productsTable.rack), asc(productsTable.slot));
  if (rows.length === 0) {
    await db.insert(productsTable).values(SEED_PRODUCTS);
    rows = await db.select().from(productsTable).orderBy(asc(productsTable.rack), asc(productsTable.slot));
  }
  return rows.map((r) => ({
    id: r.id,
    name: r.name,
    category: r.category,
    price: r.price,
    emoji: r.emoji,
    color: r.color,
    imageUrl: r.imageUrl,
    modelUrl: r.modelUrl,
    rack: r.rack,
    slot: r.slot,
  }));
}

export default async function HomePage() {
  const [products, scoreRows] = await Promise.all([
    loadProducts(),
    db.select().from(highScores).orderBy(desc(highScores.score)).limit(10),
  ]);
  const initialScores: ScoreRow[] = scoreRows.map((s) => ({
    id: s.id,
    name: s.name,
    score: s.score,
    items: s.items,
    spend: s.spend,
    createdAt: s.createdAt.toISOString(),
  }));

  return <Game products={products} initialScores={initialScores} />;
}
