"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { MartEngine, type HudState, type EndSummary, type GrabInfo } from "@/lib/martEngine";
import type { GameProduct, ScoreRow } from "@/lib/types";

const GAME_SECONDS = Number.POSITIVE_INFINITY;
const LS_KEY = "mart-dash-highscores";

type Phase = "start" | "playing" | "paused" | "over";

type LocalScore = { name: string; score: number; items: number; spend: number; at: number };

type Floaty = { id: number; text: string; sub: string; x: number; y: number; big: boolean };

function rs(n: number) {
  return "Rs " + Math.round(n).toLocaleString("en-PK");
}

const emptyHud: HudState = {
  total: 0,
  items: 0,
  score: 0,
  timeLeft: GAME_SECONDS,
  combo: 0,
  near: null,
  canCheckout: false,
  list: [],
};

export default function Game({ products, initialScores }: { products: GameProduct[]; initialScores: ScoreRow[] }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<MartEngine | null>(null);
  const [phase, setPhase] = useState<Phase>("start");
  const [hud, setHud] = useState<HudState>(emptyHud);
  const [floaties, setFloaties] = useState<Floaty[]>([]);
  const [summary, setSummary] = useState<EndSummary | null>(null);
  const [isMobile, setIsMobile] = useState(false);
  const [name, setName] = useState("");
  const [scores, setScores] = useState<ScoreRow[]>(initialScores);
  const [localScores, setLocalScores] = useState<LocalScore[]>([]);
  const [saved, setSaved] = useState(false);
  const floatId = useRef(0);

  useEffect(() => {
    setIsMobile(window.matchMedia("(pointer: coarse)").matches || "ontouchstart" in window);
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (raw) setLocalScores(JSON.parse(raw));
      const n = localStorage.getItem("mart-dash-name");
      if (n) setName(n);
    } catch {}
  }, []);

  const onGrab = useCallback((g: GrabInfo) => {
    const id = floatId.current++;
    setFloaties((f) => [
      ...f.slice(-12),
      {
        id,
        text: `+${g.points}`,
        sub: g.isList ? `✓ ${g.emoji} LIST! x${3 + g.combo}` : `${g.emoji} ${rs(g.price)}`,
        x: g.x,
        y: g.y,
        big: g.isList,
      },
    ]);
    setTimeout(() => setFloaties((f) => f.filter((x) => x.id !== id)), 950);
  }, []);

  const onEnd = useCallback((s: EndSummary) => {
    setSummary(s);
    setPhase("over");
    setSaved(false);
  }, []);

  const startEngine = useCallback(() => {
    if (!canvasRef.current) return;
    engineRef.current?.dispose();
    const eng = new MartEngine({
      canvas: canvasRef.current,
      products,
      isMobile: window.matchMedia("(pointer: coarse)").matches || "ontouchstart" in window,
      gameSeconds: GAME_SECONDS,
      onHud: setHud,
      onGrab,
      onEnd,
      onRequestPause: () => setPhase((p) => (p === "playing" ? "paused" : p)),
    });
    engineRef.current = eng;
    eng.resize();
    eng.start();
    eng.requestLock();
    setPhase("playing");
    setHud(emptyHud);
    setSummary(null);
  }, [products, onGrab, onEnd]);

  useEffect(() => {
    return () => engineRef.current?.dispose();
  }, []);

  const resume = () => {
    engineRef.current?.resume();
    engineRef.current?.requestLock();
    setPhase("playing");
  };

  const pause = () => {
    engineRef.current?.pause();
    setPhase("paused");
  };

  const quitToMenu = () => {
    engineRef.current?.dispose();
    engineRef.current = null;
    setPhase("start");
  };

  const saveScore = useCallback(async () => {
    if (!summary || saved) return;
    setSaved(true);
    const nm = (name || "Shopper").slice(0, 40);
    try {
      localStorage.setItem("mart-dash-name", nm);
    } catch {}
    const entry: LocalScore = { name: nm, score: summary.score, items: summary.items, spend: summary.spend, at: Date.now() };
    const next = [...localScores, entry].sort((a, b) => b.score - a.score).slice(0, 10);
    setLocalScores(next);
    try {
      localStorage.setItem(LS_KEY, JSON.stringify(next));
    } catch {}
    try {
      const res = await fetch("/api/scores", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: nm, score: summary.score, items: summary.items, spend: summary.spend }),
      });
      const data = await res.json();
      if (data.scores) setScores(data.scores);
    } catch {}
  }, [summary, saved, name, localScores]);

  // Touch joystick
  const joyRef = useRef<HTMLDivElement>(null);
  const joyKnob = useRef<HTMLDivElement>(null);
  const joyActive = useRef(false);
  const joyId = useRef<number | null>(null);
  const joyCenter = useRef({ x: 0, y: 0 });

  const joyStart = (e: React.PointerEvent) => {
    const rect = joyRef.current!.getBoundingClientRect();
    joyCenter.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
    joyActive.current = true;
    joyId.current = e.pointerId;
    joyMove(e);
  };
  const joyMove = (e: React.PointerEvent) => {
    if (!joyActive.current || joyId.current !== e.pointerId) return;
    const dx = e.clientX - joyCenter.current.x;
    const dy = e.clientY - joyCenter.current.y;
    const max = 46;
    const d = Math.hypot(dx, dy);
    const cl = d > max ? max / d : 1;
    const kx = dx * cl;
    const ky = dy * cl;
    if (joyKnob.current) joyKnob.current.style.transform = `translate(${kx}px,${ky}px)`;
    engineRef.current?.setMove(kx / max, -ky / max);
  };
  const joyEnd = (e: React.PointerEvent) => {
    if (joyId.current !== e.pointerId) return;
    joyActive.current = false;
    joyId.current = null;
    if (joyKnob.current) joyKnob.current.style.transform = "translate(0,0)";
    engineRef.current?.setMove(0, 0);
  };

  // Look drag on right side
  const lookId = useRef<number | null>(null);
  const lookLast = useRef({ x: 0, y: 0 });
  const lookStart = (e: React.PointerEvent) => {
    lookId.current = e.pointerId;
    lookLast.current = { x: e.clientX, y: e.clientY };
  };
  const lookMove = (e: React.PointerEvent) => {
    if (lookId.current !== e.pointerId) return;
    const dx = e.clientX - lookLast.current.x;
    const dy = e.clientY - lookLast.current.y;
    lookLast.current = { x: e.clientX, y: e.clientY };
    engineRef.current?.addLook(dx, dy);
  };
  const lookEnd = (e: React.PointerEvent) => {
    if (lookId.current === e.pointerId) lookId.current = null;
  };

  const timePct = Math.max(0, hud.timeLeft / GAME_SECONDS);
  const lowTime = hud.timeLeft <= 15;
  const listDone = hud.list.filter((l) => l.done).length;

  return (
    <div className="fixed inset-0 overflow-hidden bg-[#0b1220] text-white select-none touch-none">
      <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />

      {/* Crosshair + grab prompt */}
      {phase === "playing" && (
        <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
          <div className={`h-6 w-6 rounded-full border-2 transition-all ${hud.near ? "scale-125 border-emerald-400" : "border-white/60"}`}>
            <div className="absolute left-1/2 top-1/2 h-1 w-1 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white" />
          </div>
          {hud.near && (
            <div className="absolute left-1/2 top-9 -translate-x-1/2 whitespace-nowrap rounded-lg bg-emerald-500/90 px-3 py-1 text-sm font-bold shadow-lg">
              {hud.near.emoji} {hud.near.name} · {rs(hud.near.price)} <span className="opacity-80">— {isMobile ? "TAP GRAB" : "[E]"}</span>
            </div>
          )}
          {hud.canCheckout && !hud.near && (
            <div className="absolute left-1/2 top-9 -translate-x-1/2 whitespace-nowrap rounded-lg bg-amber-500/90 px-3 py-1 text-sm font-bold shadow-lg animate-pulse">
              💳 At checkout — {isMobile ? "TAP CHECKOUT" : "press [E]"} to pay
            </div>
          )}
        </div>
      )}

      {/* Floating score texts */}
      {floaties.map((f) => (
        <div
          key={f.id}
          className={`pointer-events-none absolute z-30 -translate-x-1/2 -translate-y-1/2 animate-[floatUp_0.95s_ease-out_forwards] text-center font-black drop-shadow-lg ${
            f.big ? "text-3xl text-amber-300" : "text-xl text-emerald-300"
          }`}
          style={{ left: f.x, top: f.y }}
        >
          {f.text}
          <div className={`font-bold ${f.big ? "text-sm text-amber-200" : "text-xs text-emerald-200"}`}>{f.sub}</div>
        </div>
      ))}

      {/* HUD */}
      {(phase === "playing" || phase === "paused") && (
        <>
          {/* top bar */}
          <div className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-3 p-3">
            <div className="flex flex-col gap-2">
              <div className="rounded-2xl bg-black/45 px-4 py-2 backdrop-blur">
                <div className="text-[10px] uppercase tracking-widest text-emerald-300">Cart Total</div>
                <div className="text-2xl font-black tabular-nums text-white">{rs(hud.total)}</div>
              </div>
              <div className="flex gap-2">
                <Chip label="Score" value={hud.score.toLocaleString()} accent="text-amber-300" />
                <Chip label="Items" value={String(hud.items)} accent="text-sky-300" />
                {hud.combo > 0 && <Chip label="Combo" value={`x${3 + hud.combo}`} accent="text-fuchsia-300" />}
              </div>
            </div>

            {/* timer */}
            <div className="rounded-2xl bg-black/45 px-4 py-2 text-center backdrop-blur">
              <div className="text-[10px] uppercase tracking-widest text-slate-300">Time</div>
              <div className={`text-2xl font-black tabular-nums ${lowTime ? "text-red-400 animate-pulse" : "text-white"}`}>
                {Math.ceil(hud.timeLeft)}s
              </div>
              <div className="mt-1 h-1.5 w-24 overflow-hidden rounded-full bg-white/20">
                <div className={`h-full rounded-full ${lowTime ? "bg-red-500" : "bg-emerald-400"}`} style={{ width: `${timePct * 100}%` }} />
              </div>
            </div>
          </div>

          {/* shopping list */}
          <div className="pointer-events-none absolute right-3 top-24 z-20 w-52 rounded-2xl bg-black/45 p-3 backdrop-blur max-[420px]:top-28 max-[420px]:w-40">
            <div className="mb-1 flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-300">📝 List</span>
              <span className="text-xs font-bold text-emerald-300">
                {listDone}/{hud.list.length}
              </span>
            </div>
            <div className="flex flex-col gap-1">
              {hud.list.map((l) => (
                <div key={l.id} className={`flex items-center gap-2 rounded-lg px-2 py-1 text-xs ${l.done ? "bg-emerald-500/25 text-emerald-200 line-through" : "bg-white/5 text-slate-200"}`}>
                  <span className="text-base">{l.emoji}</span>
                  <span className="flex-1 truncate">{l.name}</span>
                  {l.done && <span>✓</span>}
                </div>
              ))}
            </div>
          </div>

          {/* pause button */}
          {phase === "playing" && (
            <button
              onClick={pause}
              className="absolute right-3 bottom-3 z-30 rounded-full bg-black/50 px-4 py-2 text-sm font-bold backdrop-blur active:scale-95"
            >
              ⏸ Pause
            </button>
          )}
        </>
      )}

      {/* Touch controls */}
      {phase === "playing" && isMobile && (
        <>
          {/* look area (right half) */}
          <div
            className="absolute inset-y-0 right-0 z-10 w-1/2"
            onPointerDown={lookStart}
            onPointerMove={lookMove}
            onPointerUp={lookEnd}
            onPointerCancel={lookEnd}
          />
          {/* joystick (left) */}
          <div
            ref={joyRef}
            onPointerDown={joyStart}
            onPointerMove={joyMove}
            onPointerUp={joyEnd}
            onPointerCancel={joyEnd}
            className="absolute bottom-8 left-6 z-30 h-32 w-32 rounded-full border-2 border-white/25 bg-white/5 backdrop-blur"
          >
            <div ref={joyKnob} className="absolute left-1/2 top-1/2 h-14 w-14 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white/40" />
          </div>
          {/* grab button */}
          <button
            onPointerDown={(e) => {
              e.preventDefault();
              engineRef.current?.pressGrab();
            }}
            className="absolute bottom-14 right-6 z-30 h-24 w-24 rounded-full bg-emerald-500 text-lg font-black shadow-[0_8px_24px_rgba(16,185,129,0.5)] active:scale-90"
          >
            GRAB
          </button>
          {hud.canCheckout && (
            <button
              onPointerDown={(e) => {
                e.preventDefault();
                engineRef.current?.requestCheckout();
              }}
              className="absolute bottom-40 right-6 z-30 rounded-full bg-amber-500 px-5 py-3 text-sm font-black shadow-lg active:scale-90"
            >
              💳 PAY
            </button>
          )}
        </>
      )}

      {/* START SCREEN */}
      {phase === "start" && (
        <Overlay>
          <div className="w-full max-w-md text-center">
            <div className="mb-2 text-6xl">🛒</div>
            <h1 className="bg-gradient-to-r from-emerald-300 via-lime-200 to-amber-300 bg-clip-text text-4xl font-black text-transparent sm:text-5xl">
              MART DASH
            </h1>
            <p className="mt-1 text-sm font-semibold tracking-widest text-emerald-300">🇵🇰 BADSHAHI SUPER STORE</p>
            <p className="mx-auto mt-3 max-w-sm text-sm text-slate-300">
              Grab your cart, race the clock, and fill it with atta, chini, snacks &amp; more. Complete your shopping list for huge combos, then dash to checkout!
            </p>

            <div className="mt-5 grid grid-cols-2 gap-2 text-left text-xs text-slate-300">
              <Instr icon="🎮" title={isMobile ? "Joystick" : "W A S D"} desc="Move around" />
              <Instr icon="👀" title={isMobile ? "Drag right" : "Mouse"} desc="Look" />
              <Instr icon="✋" title={isMobile ? "GRAB btn" : "E / Space"} desc="Grab item" />
              <Instr icon="💳" title="Checkout" desc="Bank your score" />
            </div>

            <button
              onClick={startEngine}
              className="mt-6 w-full rounded-2xl bg-gradient-to-r from-emerald-500 to-lime-500 px-6 py-4 text-lg font-black text-slate-900 shadow-[0_10px_30px_rgba(16,185,129,0.5)] transition active:scale-95"
            >
              ▶ START SHOPPING
            </button>
            <div className="mt-3 flex items-center justify-center gap-4 text-xs">
              <Link href="/admin" className="rounded-lg bg-white/10 px-3 py-1.5 font-semibold text-slate-200 hover:bg-white/20">
                🛠 Admin Panel
              </Link>
              <span className="text-slate-500">{products.length} products stocked</span>
            </div>

            {(scores.length > 0 || localScores.length > 0) && (
              <HighScores server={scores} local={localScores} />
            )}
          </div>
        </Overlay>
      )}

      {/* PAUSE */}
      {phase === "paused" && (
        <Overlay>
          <div className="w-full max-w-sm text-center">
            <h2 className="text-4xl font-black text-white">⏸ Paused</h2>
            <p className="mt-2 text-sm text-slate-300">Cart total: {rs(hud.total)} · {hud.items} items</p>
            <button onClick={resume} className="mt-6 w-full rounded-2xl bg-emerald-500 px-6 py-4 text-lg font-black text-slate-900 active:scale-95">
              ▶ Resume
            </button>
            <button onClick={startEngine} className="mt-3 w-full rounded-2xl bg-white/10 px-6 py-3 font-bold text-white hover:bg-white/20">
              ↻ Restart
            </button>
            <button onClick={quitToMenu} className="mt-3 w-full rounded-2xl bg-white/5 px-6 py-3 font-bold text-slate-300 hover:bg-white/10">
              ⌂ Main Menu
            </button>
          </div>
        </Overlay>
      )}

      {/* GAME OVER */}
      {phase === "over" && summary && (
        <Overlay>
          <div className="w-full max-w-md text-center">
            <div className="text-5xl">{summary.reason === "checkout" ? "🎉" : "⏰"}</div>
            <h2 className="mt-2 text-3xl font-black text-white">
              {summary.reason === "checkout" ? "Checkout Complete!" : "Time's Up!"}
            </h2>
            <div className="mt-4 rounded-2xl bg-black/40 p-4">
              <div className="text-xs uppercase tracking-widest text-emerald-300">Final Score</div>
              <div className="text-5xl font-black text-amber-300">{summary.score.toLocaleString()}</div>
              <div className="mt-3 grid grid-cols-3 gap-2 text-sm">
                <Stat label="Items" value={String(summary.items)} />
                <Stat label="Spent" value={rs(summary.spend)} />
                <Stat label="List" value={`${summary.listDone}/${summary.listTotal}`} />
              </div>
              {summary.reason === "checkout" && summary.listDone === summary.listTotal && (
                <div className="mt-2 text-sm font-bold text-lime-300">✨ Full list bonus +3000!</div>
              )}
            </div>

            {!saved ? (
              <div className="mt-4 flex gap-2">
                <input
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Your name"
                  maxLength={40}
                  className="flex-1 rounded-xl bg-white/10 px-4 py-3 text-white placeholder:text-slate-400 outline-none focus:ring-2 focus:ring-emerald-400"
                />
                <button onClick={saveScore} className="rounded-xl bg-emerald-500 px-5 py-3 font-black text-slate-900 active:scale-95">
                  Save
                </button>
              </div>
            ) : (
              <div className="mt-4 text-sm font-semibold text-emerald-300">✓ Score saved to leaderboard</div>
            )}

            <button onClick={startEngine} className="mt-4 w-full rounded-2xl bg-gradient-to-r from-emerald-500 to-lime-500 px-6 py-4 text-lg font-black text-slate-900 active:scale-95">
              ↻ Play Again
            </button>
            <button onClick={quitToMenu} className="mt-3 w-full rounded-2xl bg-white/10 px-6 py-3 font-bold text-white hover:bg-white/20">
              ⌂ Main Menu
            </button>

            <HighScores server={scores} local={localScores} />
          </div>
        </Overlay>
      )}

      <style jsx global>{`
        @keyframes floatUp {
          0% { opacity: 0; transform: translate(-50%, -20%) scale(0.6); }
          20% { opacity: 1; transform: translate(-50%, -60%) scale(1.1); }
          100% { opacity: 0; transform: translate(-50%, -160%) scale(1); }
        }
      `}</style>
    </div>
  );
}

function Overlay({ children }: { children: React.ReactNode }) {
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center overflow-y-auto bg-gradient-to-b from-slate-950/80 to-slate-950/95 p-4 backdrop-blur-sm">
      {children}
    </div>
  );
}

function Chip({ label, value, accent }: { label: string; value: string; accent: string }) {
  return (
    <div className="rounded-xl bg-black/45 px-3 py-1.5 backdrop-blur">
      <div className="text-[9px] uppercase tracking-widest text-slate-400">{label}</div>
      <div className={`text-sm font-black tabular-nums ${accent}`}>{value}</div>
    </div>
  );
}

function Instr({ icon, title, desc }: { icon: string; title: string; desc: string }) {
  return (
    <div className="flex items-center gap-2 rounded-xl bg-white/5 p-2">
      <span className="text-xl">{icon}</span>
      <div>
        <div className="font-bold text-white">{title}</div>
        <div className="text-[10px] text-slate-400">{desc}</div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-white/5 py-2">
      <div className="text-[9px] uppercase tracking-widest text-slate-400">{label}</div>
      <div className="text-sm font-bold text-white">{value}</div>
    </div>
  );
}

function HighScores({ server, local }: { server: ScoreRow[]; local: LocalScore[] }) {
  const [tab, setTab] = useState<"global" | "local">(server.length ? "global" : "local");
  const rows = tab === "global" ? server : local;
  return (
    <div className="mt-5 rounded-2xl bg-black/40 p-3 text-left">
      <div className="mb-2 flex items-center gap-2">
        <span className="text-xs font-black uppercase tracking-widest text-amber-300">🏆 High Scores</span>
        <div className="ml-auto flex gap-1 text-xs">
          <button onClick={() => setTab("global")} className={`rounded-lg px-2 py-0.5 font-semibold ${tab === "global" ? "bg-emerald-500 text-slate-900" : "bg-white/10 text-slate-300"}`}>
            Global
          </button>
          <button onClick={() => setTab("local")} className={`rounded-lg px-2 py-0.5 font-semibold ${tab === "local" ? "bg-emerald-500 text-slate-900" : "bg-white/10 text-slate-300"}`}>
            You
          </button>
        </div>
      </div>
      {rows.length === 0 ? (
        <div className="py-2 text-center text-xs text-slate-400">No scores yet — be the first!</div>
      ) : (
        <div className="flex flex-col gap-1">
          {rows.slice(0, 6).map((r, i) => (
            <div key={i} className="flex items-center gap-2 rounded-lg bg-white/5 px-2 py-1 text-sm">
              <span className={`w-5 text-center font-black ${i === 0 ? "text-amber-300" : "text-slate-400"}`}>{i + 1}</span>
              <span className="flex-1 truncate font-semibold text-white">{r.name}</span>
              <span className="font-black tabular-nums text-emerald-300">{r.score.toLocaleString()}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
