import {
  integer,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

// Products stocked in the virtual mart. Managers create these in the admin panel
// and assign them to a rack + slot so the 3D store can place them on shelves.
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  category: varchar("category", { length: 60 }).notNull().default("staples"),
  price: real("price").notNull().default(0),
  emoji: varchar("emoji", { length: 16 }).notNull().default("🛒"),
  color: varchar("color", { length: 16 }).notNull().default("#f59e0b"),
  imageUrl: text("image_url"),
  modelUrl: text("model_url"),
  rack: integer("rack").notNull().default(0),
  slot: integer("slot").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// Local + server high-score table for the game.
export const highScores = pgTable("high_scores", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 40 }).notNull().default("Shopper"),
  score: integer("score").notNull().default(0),
  items: integer("items").notNull().default(0),
  spend: real("spend").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Product = typeof products.$inferSelect;
export type NewProduct = typeof products.$inferInsert;
export type HighScore = typeof highScores.$inferSelect;
