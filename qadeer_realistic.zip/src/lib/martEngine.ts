import * as THREE from "three";
import { AISLE_RACKS } from "@/lib/racks";
import type { GameProduct } from "@/lib/types";

export type HudList = {
  id: number;
  name: string;
  emoji: string;
  price: number;
  done: boolean;
};

export type HudState = {
  total: number;
  items: number;
  score: number;
  timeLeft: number;
  combo: number;
  near: { name: string; price: number; emoji: string } | null;
  canCheckout: boolean;
  list: HudList[];
};

export type GrabInfo = {
  name: string;
  emoji: string;
  price: number;
  points: number;
  isList: boolean;
  combo: number;
  x: number;
  y: number;
};

export type EndSummary = {
  reason: "timeout" | "checkout";
  score: number;
  items: number;
  spend: number;
  listDone: number;
  listTotal: number;
};

type EngineOpts = {
  canvas: HTMLCanvasElement;
  products: GameProduct[];
  isMobile: boolean;
  gameSeconds: number;
  onHud: (s: HudState) => void;
  onGrab: (g: GrabInfo) => void;
  onEnd: (s: EndSummary) => void;
  onRequestPause: () => void;
};

type Item = {
  mesh: THREE.Mesh;
  product: GameProduct;
  baseScale: number;
  homePos: THREE.Vector3;
  active: boolean;
  grabbing: number; // -1 idle, else progress 0..1
  respawnAt: number; // seconds timestamp to respawn, 0 = none
  isList: boolean;
};

const RACK_W = 4;
const RACK_D = 2;
const EYE = 1.6;
const PLAYER_R = 0.55;
const BOUND_X = 12.6;
const BOUND_Z = 8.6;

export class MartEngine {
  private opts: EngineOpts;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private clock = new THREE.Clock();
  private raf = 0;
  private running = false;
  private paused = false;

  private yaw = 0;
  private pitch = 0;
  private pos = new THREE.Vector3(0, EYE, 7.5);
  private keys = new Set<string>();
  private touchMove = new THREE.Vector2(0, 0);
  private useTouchMove = false;

  private items: Item[] = [];
  private rackBoxes: { minx: number; maxx: number; minz: number; maxz: number }[] = [];
  private targetItem: Item | null = null;
  private raycaster = new THREE.Raycaster();

  private shake = 0;
  private fovPunch = 0;
  private sprites: THREE.Sprite[] = [];
  private spriteVel: THREE.Vector3[] = [];
  private spriteLife: number[] = [];
  private spriteMax = 180;
  private spriteHead = 0;

  private cartGroup: THREE.Group;
  private elapsed = 0;
  private timeLeft: number;
  private score = 0;
  private spend = 0;
  private itemCount = 0;
  private combo = 0;
  private listIds: number[] = [];
  private listDone = new Set<number>();
  private canCheckout = false;
  private hudTimer = 0;
  private ended = false;

  private audio: AudioContext | null = null;
  private locked = false;

  private tmpVec = new THREE.Vector3();
  private tmpDir = new THREE.Vector3();

  constructor(opts: EngineOpts) {
    this.opts = opts;
    this.timeLeft = opts.gameSeconds;

    this.renderer = new THREE.WebGLRenderer({
      canvas: opts.canvas,
      antialias: !opts.isMobile,
      powerPreference: "high-performance",
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, opts.isMobile ? 1.5 : 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color("#0b1220");
    this.scene.fog = new THREE.Fog("#101a2e", 16, 40);

    this.camera = new THREE.PerspectiveCamera(72, 1, 0.1, 100);

    this.cartGroup = new THREE.Group();
    this.buildStore();
    this.buildCart();
    this.buildItems();
    this.buildParticles();
    this.pickList();

    this.bind();
    this.resize();
  }

  // ---------- Build world ----------
  private buildStore() {
    const hemi = new THREE.HemisphereLight(0xffffff, 0x3b4654, 1.15);
    this.scene.add(hemi);

    const dir = new THREE.DirectionalLight(0xfff3d6, 1.15);
    dir.position.set(5, 14, 6);
    dir.castShadow = true;
    dir.shadow.mapSize.set(2048, 2048);
    dir.shadow.camera.near = 1;
    dir.shadow.camera.far = 45;
    dir.shadow.camera.left = -22;
    dir.shadow.camera.right = 22;
    dir.shadow.camera.top = 22;
    dir.shadow.camera.bottom = -22;
    this.scene.add(dir);

    // Warm ceiling downlights for a more realistic retail atmosphere.
    for (let x = -10; x <= 10; x += 5) {
      for (let z = -7; z <= 7; z += 7) {
        const light = new THREE.PointLight(0xfff7df, 0.55, 10, 2);
        light.position.set(x, 4.55, z);
        light.castShadow = false;
        this.scene.add(light);

        const housing = new THREE.Mesh(
          new THREE.CylinderGeometry(0.22, 0.3, 0.08, 24),
          new THREE.MeshStandardMaterial({ color: 0xf3f4f6, roughness: 0.35, metalness: 0.25 })
        );
        housing.position.set(x, 4.92, z);
        this.scene.add(housing);
      }
    }

    // Floor: larger ceramic tiles with subtle variation.
    const floorTex = this.makeCheckerTexture();
    floorTex.wrapS = floorTex.wrapT = THREE.RepeatWrapping;
    floorTex.repeat.set(14, 10);
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(28, 20),
      new THREE.MeshStandardMaterial({ map: floorTex, roughness: 0.42, metalness: 0.08 })
    );
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    this.scene.add(floor);

    const ceil = new THREE.Mesh(
      new THREE.PlaneGeometry(28, 20),
      new THREE.MeshStandardMaterial({ color: 0xf3f4f6, roughness: 0.92 })
    );
    ceil.rotation.x = Math.PI / 2;
    ceil.position.y = 5;
    this.scene.add(ceil);

    // Clean painted walls.
    const wallMat = new THREE.MeshStandardMaterial({ color: 0xe5e7eb, roughness: 0.9 });
    const mkWall = (w: number, x: number, z: number, ry: number) => {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, 5, 0.4), wallMat);
      m.position.set(x, 2.5, z);
      m.rotation.y = ry;
      m.castShadow = true;
      m.receiveShadow = true;
      this.scene.add(m);
    };
    mkWall(28, 0, -10, 0);
    mkWall(28, 0, 10, 0);
    mkWall(20, -14, 0, Math.PI / 2);
    mkWall(20, 14, 0, Math.PI / 2);

    // Front glass windows/doors: gives the mart a recognizable real-world entrance.
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xbfe7ff,
      transparent: true,
      opacity: 0.26,
      roughness: 0.08,
      metalness: 0.08,
      transmission: 0.35,
      thickness: 0.04,
    });
    const frameMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.7, roughness: 0.28 });

    for (const x of [-8, -4, 0, 4, 8]) {
      const glass = new THREE.Mesh(new THREE.BoxGeometry(3.4, 3.0, 0.06), glassMat);
      glass.position.set(x, 2.35, -9.77);
      this.scene.add(glass);

      const top = new THREE.Mesh(new THREE.BoxGeometry(3.55, 0.09, 0.12), frameMat);
      top.position.set(x, 3.9, -9.72);
      this.scene.add(top);

      const left = new THREE.Mesh(new THREE.BoxGeometry(0.09, 3.1, 0.12), frameMat);
      left.position.set(x - 1.72, 2.35, -9.72);
      this.scene.add(left);

      const right = left.clone();
      right.position.x = x + 1.72;
      this.scene.add(right);
    }

    // Main entrance doors.
    for (const x of [-1.05, 1.05]) {
      const door = new THREE.Mesh(new THREE.BoxGeometry(1.9, 3.0, 0.08), glassMat);
      door.position.set(x, 2.35, -9.66);
      this.scene.add(door);
    }

    // Storefront banner.
    const banner = new THREE.Mesh(
      new THREE.PlaneGeometry(12, 2.2),
      new THREE.MeshBasicMaterial({
        map: this.makeSignTexture("🛒  BADSHAHI MART  🛒", "SUPER STORE • PAKISTAN", "#16a34a"),
        transparent: true
      })
    );
    banner.position.set(0, 3.6, -9.48);
    this.scene.add(banner);

    // Aisle racks with better materials and shadows.
    AISLE_RACKS.forEach((r) => {
      const g = new THREE.Group();
      g.position.set(r.x, 0, r.z);
      g.rotation.y = r.rot;

      const body = new THREE.Mesh(
        new THREE.BoxGeometry(RACK_W, 2.1, RACK_D),
        new THREE.MeshStandardMaterial({ color: 0x475569, roughness: 0.5, metalness: 0.35 })
      );
      body.position.y = 1.05;
      body.castShadow = true;
      body.receiveShadow = true;
      g.add(body);

      const shelfMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.45, roughness: 0.38 });
      [0.65, 1.45, 2.15].forEach((yy) => {
        const sh = new THREE.Mesh(new THREE.BoxGeometry(RACK_W, 0.08, RACK_D + 0.1), shelfMat);
        sh.position.y = yy;
        sh.castShadow = true;
        sh.receiveShadow = true;
        g.add(sh);
      });

      const sign = new THREE.Mesh(
        new THREE.PlaneGeometry(RACK_W, 0.7),
        new THREE.MeshBasicMaterial({
          map: this.makeSignTexture(`${r.emoji} ${r.label}`, "", "#0ea5e9"),
          transparent: true
        })
      );
      sign.position.set(0, 2.65, RACK_D / 2 + 0.02);
      g.add(sign);

      const sign2 = sign.clone();
      sign2.rotation.y = Math.PI;
      sign2.position.set(0, 2.65, -RACK_D / 2 - 0.02);
      g.add(sign2);

      this.scene.add(g);

      this.rackBoxes.push({
        minx: r.x - RACK_W / 2 - 0.1,
        maxx: r.x + RACK_W / 2 + 0.1,
        minz: r.z - RACK_D / 2 - 0.1,
        maxz: r.z + RACK_D / 2 + 0.1,
      });
    });

    // Checkout counter with a glowing payment screen.
    const counter = new THREE.Mesh(
      new THREE.BoxGeometry(4, 1, 1.4),
      new THREE.MeshStandardMaterial({ color: 0x0f766e, roughness: 0.38, metalness: 0.25 })
    );
    counter.position.set(8, 0.5, 8);
    counter.castShadow = true;
    counter.receiveShadow = true;
    this.scene.add(counter);

    const screen = new THREE.Mesh(
      new THREE.BoxGeometry(1.2, 0.65, 0.06),
      new THREE.MeshStandardMaterial({
        color: 0x0b1220,
        emissive: 0x10b981,
        emissiveIntensity: 0.45,
        metalness: 0.5,
        roughness: 0.2,
      })
    );
    screen.position.set(8, 1.25, 7.35);
    screen.rotation.x = -0.15;
    this.scene.add(screen);

    const csign = new THREE.Mesh(
      new THREE.PlaneGeometry(4, 1),
      new THREE.MeshBasicMaterial({
        map: this.makeSignTexture("💳 CHECKOUT", "CASH • CARD • DIGITAL", "#f59e0b"),
        transparent: true
      })
    );
    csign.position.set(8, 2.3, 7.25);
    this.scene.add(csign);

    this.rackBoxes.push({ minx: 6, maxx: 10, minz: 7.3, maxz: 8.7 });
  }

  private buildCart() {
    const mat = new THREE.MeshStandardMaterial({ color: 0xcbd5e1, metalness: 0.6, roughness: 0.4 });
    const basket = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.4, 0.55), mat);
    basket.position.set(0, -0.9, -0.95);
    const wire = new THREE.Mesh(
      new THREE.BoxGeometry(0.9, 0.42, 0.55),
      new THREE.MeshBasicMaterial({ color: 0x94a3b8, wireframe: true })
    );
    wire.position.copy(basket.position);
    const handle = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 0.9), mat);
    handle.rotation.z = Math.PI / 2;
    handle.position.set(0, -0.72, -0.65);
    this.cartGroup.add(basket, wire, handle);
    this.camera.add(this.cartGroup);
    this.scene.add(this.camera);
  }

  private buildItems() {
    const geo = new THREE.BoxGeometry(0.62, 0.62, 0.5);
    this.opts.products.forEach((p) => {
      const rack = AISLE_RACKS[p.rack] ?? AISLE_RACKS[0];
      const side = p.slot < 3 ? 1 : -1; // front (+z local) / back (-z local)
      const withinSide = p.slot % 3; // 0,1,2
      const localX = (withinSide - 1) * 1.25;
      const localZ = side * (RACK_D / 2 + 0.28);
      const yy = p.slot < 3 ? 1.15 : 1.15; // single readable row per side
      // rotate local by rack.rot
      const cos = Math.cos(rack.rot);
      const sin = Math.sin(rack.rot);
      const wx = rack.x + localX * cos + localZ * sin;
      const wz = rack.z - localX * sin + localZ * cos;

      const mat = new THREE.MeshStandardMaterial({
        map: this.makeLabelTexture(p),
        color: 0xffffff,
        roughness: 0.55,
        metalness: 0.05,
        emissive: new THREE.Color(p.color),
        emissiveIntensity: 0,
      });
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(wx, yy, wz);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.rotation.y = rack.rot + (side === 1 ? 0 : Math.PI);
      this.scene.add(mesh);

      this.items.push({
        mesh,
        product: p,
        baseScale: 1,
        homePos: new THREE.Vector3(wx, yy, wz),
        active: true,
        grabbing: -1,
        respawnAt: 0,
        isList: false,
      });
    });
  }

  private buildParticles() {
    const tex = this.makeDotTexture();
    for (let i = 0; i < this.spriteMax; i++) {
      const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
      const s = new THREE.Sprite(mat);
      s.visible = false;
      s.scale.setScalar(0.2);
      this.scene.add(s);
      this.sprites.push(s);
      this.spriteVel.push(new THREE.Vector3());
      this.spriteLife.push(0);
    }
  }

  private pickList() {
    const pool = [...this.items];
    for (let i = pool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pool[i], pool[j]] = [pool[j], pool[i]];
    }
    const chosen = pool.slice(0, Math.min(6, pool.length));
    chosen.forEach((it) => {
      it.isList = true;
      this.listIds.push(it.product.id);
    });
  }

  // ---------- Textures ----------
  private makeCheckerTexture(): THREE.Texture {
    const c = document.createElement("canvas");
    c.width = c.height = 128;
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = "#e2e8f0";
    ctx.fillRect(0, 0, 128, 128);
    ctx.fillStyle = "#cbd5e1";
    ctx.fillRect(0, 0, 64, 64);
    ctx.fillRect(64, 64, 64, 64);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }

  private makeDotTexture(): THREE.Texture {
    const c = document.createElement("canvas");
    c.width = c.height = 64;
    const ctx = c.getContext("2d")!;
    const g = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
    g.addColorStop(0, "rgba(255,255,255,1)");
    g.addColorStop(0.3, "rgba(255,255,255,0.9)");
    g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 64, 64);
    return new THREE.CanvasTexture(c);
  }

  private makeSignTexture(title: string, sub: string, color: string): THREE.Texture {
    const c = document.createElement("canvas");
    c.width = 512;
    c.height = 128;
    const ctx = c.getContext("2d")!;
    const grad = ctx.createLinearGradient(0, 0, 512, 0);
    grad.addColorStop(0, color);
    grad.addColorStop(1, "#0b1220");
    ctx.fillStyle = grad;
    roundRect(ctx, 6, 6, 500, 116, 18);
    ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.6)";
    ctx.lineWidth = 4;
    roundRect(ctx, 6, 6, 500, 116, 18);
    ctx.stroke();
    ctx.fillStyle = "#ffffff";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = "bold 46px system-ui, sans-serif";
    ctx.fillText(title, 256, sub ? 50 : 64);
    if (sub) {
      ctx.font = "500 26px system-ui, sans-serif";
      ctx.fillStyle = "rgba(255,255,255,0.85)";
      ctx.fillText(sub, 256, 92);
    }
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }

  private makeLabelTexture(p: GameProduct): THREE.Texture {
    const c = document.createElement("canvas");
    c.width = c.height = 256;
    const ctx = c.getContext("2d")!;
    ctx.fillStyle = p.color;
    ctx.fillRect(0, 0, 256, 256);
    ctx.fillStyle = "rgba(255,255,255,0.16)";
    ctx.fillRect(0, 0, 256, 90);
    // emoji
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.font = "120px system-ui, sans-serif";
    ctx.fillText(p.emoji || "🛒", 128, 120);
    // name band
    ctx.fillStyle = "rgba(15,23,42,0.82)";
    ctx.fillRect(0, 186, 256, 70);
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 26px system-ui, sans-serif";
    const name = p.name.length > 16 ? p.name.slice(0, 15) + "…" : p.name;
    ctx.fillText(name, 128, 208);
    ctx.fillStyle = "#fde047";
    ctx.font = "bold 30px system-ui, sans-serif";
    ctx.fillText(`Rs ${Math.round(p.price)}`, 128, 238);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 4;
    return t;
  }

  // ---------- Input ----------
  private bind() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("resize", this.resize);
    this.opts.canvas.addEventListener("mousemove", this.onMouseMove);
    this.opts.canvas.addEventListener("click", this.onCanvasClick);
    document.addEventListener("pointerlockchange", this.onLockChange);
  }

  private unbind() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("resize", this.resize);
    this.opts.canvas.removeEventListener("mousemove", this.onMouseMove);
    this.opts.canvas.removeEventListener("click", this.onCanvasClick);
    document.removeEventListener("pointerlockchange", this.onLockChange);
  }

  private onKeyDown = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    if (["w", "a", "s", "d", "arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault();
    if (k === "e" || k === " ") {
      this.pressGrab();
      return;
    }
    if (k === "escape") {
      this.opts.onRequestPause();
      return;
    }
    if (k === "p") {
      this.opts.onRequestPause();
      return;
    }
    this.keys.add(k);
    this.useTouchMove = false;
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys.delete(e.key.toLowerCase());
  };

  private onMouseMove = (e: MouseEvent) => {
    if (!this.locked || this.paused) return;
    const s = 0.0022;
    this.yaw -= e.movementX * s;
    this.pitch -= e.movementY * s;
    this.clampPitch();
  };

  private onCanvasClick = () => {
    if (this.paused || this.ended) return;
    if (!this.opts.isMobile && !this.locked) {
      this.opts.canvas.requestPointerLock?.();
    }
  };

  private onLockChange = () => {
    this.locked = document.pointerLockElement === this.opts.canvas;
    if (!this.locked && this.running && !this.paused && !this.ended && !this.opts.isMobile) {
      this.opts.onRequestPause();
    }
  };

  private clampPitch() {
    const lim = Math.PI / 2 - 0.15;
    this.pitch = Math.max(-lim, Math.min(lim, this.pitch));
  }

  // public touch API
  setMove(x: number, y: number) {
    this.touchMove.set(x, y);
    this.useTouchMove = true;
  }
  addLook(dx: number, dy: number) {
    if (this.paused) return;
    const s = 0.006;
    this.yaw -= dx * s;
    this.pitch -= dy * s;
    this.clampPitch();
  }

  pressGrab() {
    if (this.paused || this.ended) return;
    if (this.targetItem && this.targetItem.grabbing < 0) {
      this.grab(this.targetItem);
    } else if (this.canCheckout && this.itemCount > 0) {
      this.checkout("checkout");
    }
  }

  requestCheckout() {
    if (this.canCheckout && this.itemCount > 0) this.checkout("checkout");
  }

  requestLock() {
    if (!this.opts.isMobile) this.opts.canvas.requestPointerLock?.();
  }

  // ---------- Core loop ----------
  start() {
    this.running = true;
    this.paused = false;
    this.clock.start();
    this.ensureAudio();
    this.loop();
  }

  pause() {
    this.paused = true;
    if (this.locked) document.exitPointerLock?.();
  }

  resume() {
    if (this.ended) return;
    this.paused = false;
    this.clock.getDelta();
  }

  private loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    if (!this.paused && !this.ended) this.update(dt);
    this.render();
  };

  private update(dt: number) {
    this.elapsed += dt;
    this.timeLeft -= dt;
    if (this.timeLeft <= 0) {
      this.timeLeft = 0;
      this.checkout("timeout");
      return;
    }

    // movement input
    let mx = 0;
    let mz = 0;
    if (this.useTouchMove) {
      mx = this.touchMove.x;
      mz = -this.touchMove.y;
    } else {
      if (this.keys.has("w") || this.keys.has("arrowup")) mz -= 1;
      if (this.keys.has("s") || this.keys.has("arrowdown")) mz += 1;
      if (this.keys.has("a") || this.keys.has("arrowleft")) mx -= 1;
      if (this.keys.has("d") || this.keys.has("arrowright")) mx += 1;
    }
    const len = Math.hypot(mx, mz);
    if (len > 1) {
      mx /= len;
      mz /= len;
    }

    // direction from yaw
    const sinY = Math.sin(this.yaw);
    const cosY = Math.cos(this.yaw);
    // forward (-Z) rotated by yaw: (-sinY,0,-cosY); right: (cosY,0,-sinY)
    const speed = 5.4;
    const vx = (-sinY * -mz + cosY * mx) * speed * dt;
    const vz = (-cosY * -mz - sinY * mx) * speed * dt;

    this.moveWithCollision(vx, vz);

    // checkout zone
    this.canCheckout = this.pos.x > 5 && this.pos.x < 11 && this.pos.z > 6.4;

    // camera transform
    this.camera.position.copy(this.pos);
    if (this.shake > 0) {
      this.camera.position.x += (Math.random() - 0.5) * this.shake;
      this.camera.position.y += (Math.random() - 0.5) * this.shake;
      this.camera.position.z += (Math.random() - 0.5) * this.shake * 0.5;
      this.shake = Math.max(0, this.shake - dt * 1.6);
    }
    const e = new THREE.Euler(this.pitch, this.yaw, 0, "YXZ");
    this.camera.quaternion.setFromEuler(e);
    // fov punch
    const targetFov = 72 - this.fovPunch;
    this.camera.fov += (targetFov - this.camera.fov) * Math.min(1, dt * 12);
    this.fovPunch = Math.max(0, this.fovPunch - dt * 18);
    this.camera.updateProjectionMatrix();

    this.updateTargeting(dt);
    this.updateGrabbing(dt);
    this.updateRespawns();
    this.updateParticles(dt);
    this.pushHud(dt);
  }

  private moveWithCollision(vx: number, vz: number) {
    // X axis
    let nx = this.pos.x + vx;
    if (!this.hitsRack(nx, this.pos.z)) this.pos.x = nx;
    // Z axis
    let nz = this.pos.z + vz;
    if (!this.hitsRack(this.pos.x, nz)) this.pos.z = nz;
    this.pos.x = Math.max(-BOUND_X, Math.min(BOUND_X, this.pos.x));
    this.pos.z = Math.max(-BOUND_Z, Math.min(BOUND_Z, this.pos.z));
  }

  private hitsRack(x: number, z: number): boolean {
    for (const b of this.rackBoxes) {
      if (x > b.minx - PLAYER_R && x < b.maxx + PLAYER_R && z > b.minz - PLAYER_R && z < b.maxz + PLAYER_R) {
        return true;
      }
    }
    return false;
  }

  private updateTargeting(dt: number) {
    this.raycaster.setFromCamera(new THREE.Vector2(0, 0), this.camera);
    this.raycaster.far = 3.8;
    const meshes = this.items.filter((i) => i.active && i.grabbing < 0).map((i) => i.mesh);
    const hits = this.raycaster.intersectObjects(meshes, false);
    let newTarget: Item | null = null;
    if (hits.length) {
      const m = hits[0].object;
      newTarget = this.items.find((i) => i.mesh === m) ?? null;
    }
    if (newTarget !== this.targetItem) {
      if (this.targetItem) {
        (this.targetItem.mesh.material as THREE.MeshStandardMaterial).emissiveIntensity = 0;
        this.targetItem.mesh.scale.setScalar(1);
      }
      this.targetItem = newTarget;
    }
    if (this.targetItem) {
      const pulse = 1 + Math.sin(this.elapsed * 9) * 0.06;
      this.targetItem.mesh.scale.setScalar(pulse * 1.08);
      (this.targetItem.mesh.material as THREE.MeshStandardMaterial).emissiveIntensity =
        0.4 + Math.sin(this.elapsed * 9) * 0.2;
    }
  }

  private grab(it: Item) {
    it.grabbing = 0;
    it.active = false;
    if (this.targetItem === it) this.targetItem = null;
    (it.mesh.material as THREE.MeshStandardMaterial).emissiveIntensity = 0;

    const isList = it.isList && !this.listDone.has(it.product.id);
    if (isList) {
      this.listDone.add(it.product.id);
      this.combo += 1;
    } else {
      this.combo = Math.max(0, this.combo - 0); // keep combo, only list builds it
    }
    const base = Math.max(5, Math.round(it.product.price / 5));
    const mult = isList ? 3 + this.combo : 1;
    const points = base * mult + (isList ? 300 : 0);
    this.score += points;
    this.spend += it.product.price;
    this.itemCount += 1;

    // juice
    this.shake += isList ? 0.35 : 0.16;
    this.fovPunch += isList ? 7 : 3;
    this.spawnBurst(it.homePos, it.product.color, isList ? 26 : 14);
    this.beep(isList);

    // screen coords for floating text
    this.tmpVec.copy(it.homePos).project(this.camera);
    const sx = (this.tmpVec.x * 0.5 + 0.5) * this.opts.canvas.clientWidth;
    const sy = (-this.tmpVec.y * 0.5 + 0.5) * this.opts.canvas.clientHeight;

    this.opts.onGrab({
      name: it.product.name,
      emoji: it.product.emoji,
      price: it.product.price,
      points,
      isList,
      combo: this.combo,
      x: sx,
      y: sy,
    });
    this.pushHud(1, true);
  }

  private updateGrabbing(dt: number) {
    // Compute a world point in front-bottom of camera (into the cart).
    this.camera.getWorldDirection(this.tmpDir);
    for (const it of this.items) {
      if (it.grabbing < 0) continue;
      it.grabbing += dt * 3.2;
      const target = this.tmpVec
        .copy(this.camera.position)
        .addScaledVector(this.tmpDir, 1.1);
      target.y -= 0.7;
      it.mesh.position.lerp(target, Math.min(1, it.grabbing * 1.2));
      const s = Math.max(0.02, 1 - it.grabbing);
      it.mesh.scale.setScalar(s);
      it.mesh.rotation.x += dt * 10;
      it.mesh.rotation.y += dt * 8;
      if (it.grabbing >= 1) {
        it.grabbing = -1;
        it.mesh.visible = false;
        it.mesh.scale.setScalar(1);
        it.mesh.rotation.set(0, it.mesh.rotation.y, 0);
        // respawn non-list items to keep shelves lively; list items stay collected
        if (!it.isList) it.respawnAt = this.elapsed + 5;
      }
    }
  }

  private updateRespawns() {
    for (const it of this.items) {
      if (it.respawnAt > 0 && this.elapsed >= it.respawnAt) {
        it.respawnAt = 0;
        it.active = true;
        it.mesh.visible = true;
        it.mesh.position.copy(it.homePos);
        it.mesh.scale.setScalar(0.01);
      }
      if (it.active && it.mesh.visible && it.mesh.scale.x < 1 && it.grabbing < 0 && this.targetItem !== it) {
        it.mesh.scale.setScalar(Math.min(1, it.mesh.scale.x + 0.08));
      }
    }
  }

  // ---------- Particles ----------
  private spawnBurst(at: THREE.Vector3, color: string, n: number) {
    const col = new THREE.Color(color);
    for (let i = 0; i < n; i++) {
      const idx = this.spriteHead;
      this.spriteHead = (this.spriteHead + 1) % this.spriteMax;
      const s = this.sprites[idx];
      s.visible = true;
      s.position.copy(at);
      (s.material as THREE.SpriteMaterial).color.copy(col).lerp(new THREE.Color(0xffffff), Math.random() * 0.5);
      (s.material as THREE.SpriteMaterial).opacity = 1;
      const speed = 1.5 + Math.random() * 2.5;
      const ang = Math.random() * Math.PI * 2;
      const up = 1 + Math.random() * 2.5;
      this.spriteVel[idx].set(Math.cos(ang) * speed, up, Math.sin(ang) * speed);
      this.spriteLife[idx] = 0.7 + Math.random() * 0.3;
      s.scale.setScalar(0.15 + Math.random() * 0.2);
    }
  }

  private updateParticles(dt: number) {
    for (let i = 0; i < this.spriteMax; i++) {
      if (!this.sprites[i].visible) continue;
      this.spriteLife[i] -= dt;
      if (this.spriteLife[i] <= 0) {
        this.sprites[i].visible = false;
        continue;
      }
      this.spriteVel[i].y -= dt * 6;
      this.sprites[i].position.addScaledVector(this.spriteVel[i], dt);
      const mat = this.sprites[i].material as THREE.SpriteMaterial;
      mat.opacity = Math.min(1, this.spriteLife[i] * 2.2);
    }
  }

  // ---------- HUD ----------
  private pushHud(dt: number, force = false) {
    this.hudTimer -= dt;
    if (!force && this.hudTimer > 0) return;
    this.hudTimer = 0.08;
    const list: HudList[] = this.listIds.map((id) => {
      const it = this.items.find((i) => i.product.id === id)!;
      return {
        id,
        name: it.product.name,
        emoji: it.product.emoji,
        price: it.product.price,
        done: this.listDone.has(id),
      };
    });
    this.opts.onHud({
      total: this.spend,
      items: this.itemCount,
      score: this.score,
      timeLeft: this.timeLeft,
      combo: this.combo,
      near: this.targetItem
        ? { name: this.targetItem.product.name, price: this.targetItem.product.price, emoji: this.targetItem.product.emoji }
        : null,
      canCheckout: this.canCheckout && this.itemCount > 0,
      list,
    });
  }

  private checkout(reason: "timeout" | "checkout") {
    if (this.ended) return;
    this.ended = true;
    if (this.locked) document.exitPointerLock?.();
    let finalScore = this.score;
    if (reason === "checkout") {
      finalScore += Math.round(this.timeLeft) * 30;
      if (this.listDone.size === this.listIds.length) finalScore += 3000;
      this.beep(true);
      this.spawnBurst(this.tmpVec.copy(this.pos).addScaledVector(this.tmpDir.set(0, -0.2, -1), 1), "#fde047", 40);
    }
    this.opts.onEnd({
      reason,
      score: finalScore,
      items: this.itemCount,
      spend: this.spend,
      listDone: this.listDone.size,
      listTotal: this.listIds.length,
    });
  }

  // ---------- Audio ----------
  private ensureAudio() {
    if (this.audio) return;
    try {
      const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audio = new Ctx();
    } catch {
      this.audio = null;
    }
  }

  private beep(big: boolean) {
    if (!this.audio) return;
    const ctx = this.audio;
    if (ctx.state === "suspended") ctx.resume();
    const now = ctx.currentTime;
    const notes = big ? [523.25, 659.25, 783.99] : [440, 660];
    notes.forEach((f, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = big ? "triangle" : "square";
      o.frequency.value = f;
      g.gain.setValueAtTime(0.0001, now + i * 0.05);
      g.gain.exponentialRampToValueAtTime(0.12, now + i * 0.05 + 0.01);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.05 + 0.18);
      o.connect(g).connect(ctx.destination);
      o.start(now + i * 0.05);
      o.stop(now + i * 0.05 + 0.2);
    });
  }

  // ---------- Misc ----------
  private render() {
    this.renderer.render(this.scene, this.camera);
  }

  resize = () => {
    const w = this.opts.canvas.clientWidth || window.innerWidth;
    const h = this.opts.canvas.clientHeight || window.innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
  };

  dispose() {
    this.running = false;
    cancelAnimationFrame(this.raf);
    this.unbind();
    this.renderer.dispose();
    this.scene.traverse((o) => {
      if (o instanceof THREE.Mesh) {
        o.geometry?.dispose?.();
        const m = o.material;
        if (Array.isArray(m)) m.forEach((mm) => mm.dispose());
        else m?.dispose?.();
      }
    });
    if (this.audio) this.audio.close().catch(() => {});
  }
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}
