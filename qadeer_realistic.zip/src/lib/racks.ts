// Shared rack layout definitions. These describe where each shelf gondola sits in
// the 3D mart. Both the admin panel (for placement) and the game (for spawning
// products) rely on this single source of truth.

export type Rack = {
  id: number;
  label: string;
  category: string;
  emoji: string;
  // Center position of the gondola on the floor.
  x: number;
  z: number;
  // Facing rotation in radians (items face -z of the rack local frame).
  rot: number;
  // Number of product slots available (front face).
  slots: number;
};

export const AISLE_RACKS: Rack[] = [
  { id: 0, label: "Snacks & Chips", category: "snacks", emoji: "🍿", x: -8, z: -4, rot: 0, slots: 6 },
  { id: 1, label: "Biscuits & Sweets", category: "snacks", emoji: "🍪", x: -8, z: 4, rot: 0, slots: 6 },
  { id: 2, label: "Dairy & Chilled", category: "dairy", emoji: "🥛", x: -2, z: -4, rot: 0, slots: 6 },
  { id: 3, label: "Beverages", category: "beverages", emoji: "🧃", x: -2, z: 4, rot: 0, slots: 6 },
  { id: 4, label: "Fresh Produce", category: "produce", emoji: "🥬", x: 4, z: -4, rot: 0, slots: 6 },
  { id: 5, label: "Household Essentials", category: "household", emoji: "🧼", x: 4, z: 4, rot: 0, slots: 6 },
  { id: 6, label: "Atta, Chini & Staples", category: "staples", emoji: "🌾", x: 10, z: -4, rot: 0, slots: 6 },
  { id: 7, label: "Masala & Cooking", category: "staples", emoji: "🌶️", x: 10, z: 4, rot: 0, slots: 6 },
];

export const CATEGORIES = [
  { id: "snacks", label: "Snacks", emoji: "🍿" },
  { id: "dairy", label: "Dairy", emoji: "🥛" },
  { id: "produce", label: "Fresh Produce", emoji: "🥬" },
  { id: "beverages", label: "Beverages", emoji: "🧃" },
  { id: "household", label: "Household", emoji: "🧼" },
  { id: "staples", label: "Staples", emoji: "🌾" },
] as const;

export function rackById(id: number): Rack | undefined {
  return AISLE_RACKS.find((r) => r.id === id);
}
