import type { NewProduct } from "@/db/schema";

// A rich starter catalogue of items you'd find in a Pakistani mart / kiryana store.
// price is in PKR. rack maps to AISLE_RACKS ids, slot is the shelf position.
export const SEED_PRODUCTS: NewProduct[] = [
  // Snacks & Chips (rack 0)
  { name: "Lays Masala", category: "snacks", price: 100, emoji: "🥔", color: "#eab308", rack: 0, slot: 0 },
  { name: "Kurkure Chutney", category: "snacks", price: 50, emoji: "🌽", color: "#f97316", rack: 0, slot: 1 },
  { name: "Slanty Salted", category: "snacks", price: 40, emoji: "🍟", color: "#fbbf24", rack: 0, slot: 2 },
  { name: "Super Crisp", category: "snacks", price: 60, emoji: "🥨", color: "#f59e0b", rack: 0, slot: 3 },
  { name: "Peanuts (Moong Phali)", category: "snacks", price: 120, emoji: "🥜", color: "#d97706", rack: 0, slot: 4 },
  { name: "Popcorn Pack", category: "snacks", price: 80, emoji: "🍿", color: "#fcd34d", rack: 0, slot: 5 },

  // Biscuits & Sweets (rack 1)
  { name: "Sooper Biscuit", category: "snacks", price: 70, emoji: "🍪", color: "#b45309", rack: 1, slot: 0 },
  { name: "Prince Bourbon", category: "snacks", price: 90, emoji: "🍫", color: "#78350f", rack: 1, slot: 1 },
  { name: "Candi Gulab", category: "snacks", price: 30, emoji: "🍬", color: "#ec4899", rack: 1, slot: 2 },
  { name: "Dairy Milk", category: "snacks", price: 150, emoji: "🍫", color: "#6d28d9", rack: 1, slot: 3 },
  { name: "Jelly Sweets", category: "snacks", price: 45, emoji: "🍭", color: "#f43f5e", rack: 1, slot: 4 },
  { name: "Rusk (Baqarkhani)", category: "snacks", price: 110, emoji: "🥖", color: "#ca8a04", rack: 1, slot: 5 },

  // Dairy & Chilled (rack 2)
  { name: "Olpers Milk 1L", category: "dairy", price: 290, emoji: "🥛", color: "#60a5fa", rack: 2, slot: 0 },
  { name: "Nurpur Butter", category: "dairy", price: 260, emoji: "🧈", color: "#fde047", rack: 2, slot: 1 },
  { name: "Dahi (Yogurt) 500g", category: "dairy", price: 180, emoji: "🍶", color: "#e2e8f0", rack: 2, slot: 2 },
  { name: "Cheese Slices", category: "dairy", price: 420, emoji: "🧀", color: "#facc15", rack: 2, slot: 3 },
  { name: "Fresh Eggs (dozen)", category: "dairy", price: 320, emoji: "🥚", color: "#fef3c7", rack: 2, slot: 4 },
  { name: "Nido Powder", category: "dairy", price: 950, emoji: "🥫", color: "#38bdf8", rack: 2, slot: 5 },

  // Beverages (rack 3)
  { name: "Coca Cola 1.5L", category: "beverages", price: 180, emoji: "🥤", color: "#dc2626", rack: 3, slot: 0 },
  { name: "Nestle Water", category: "beverages", price: 90, emoji: "💧", color: "#0ea5e9", rack: 3, slot: 1 },
  { name: "Rooh Afza", category: "beverages", price: 480, emoji: "🧃", color: "#be123c", rack: 3, slot: 2 },
  { name: "Tang Orange", category: "beverages", price: 120, emoji: "🍊", color: "#f97316", rack: 3, slot: 3 },
  { name: "Lipton Chai Pack", category: "beverages", price: 650, emoji: "🍵", color: "#eab308", rack: 3, slot: 4 },
  { name: "Nestle Juice", category: "beverages", price: 100, emoji: "🧃", color: "#22c55e", rack: 3, slot: 5 },

  // Fresh Produce (rack 4)
  { name: "Aloo (Potato) 1kg", category: "produce", price: 80, emoji: "🥔", color: "#a16207", rack: 4, slot: 0 },
  { name: "Pyaz (Onion) 1kg", category: "produce", price: 120, emoji: "🧅", color: "#c084fc", rack: 4, slot: 1 },
  { name: "Tamatar (Tomato) 1kg", category: "produce", price: 150, emoji: "🍅", color: "#ef4444", rack: 4, slot: 2 },
  { name: "Kela (Banana) dozen", category: "produce", price: 200, emoji: "🍌", color: "#fde047", rack: 4, slot: 3 },
  { name: "Aam (Mango) 1kg", category: "produce", price: 250, emoji: "🥭", color: "#f59e0b", rack: 4, slot: 4 },
  { name: "Hari Mirch 250g", category: "produce", price: 60, emoji: "🌶️", color: "#16a34a", rack: 4, slot: 5 },

  // Household Essentials (rack 5)
  { name: "Surf Excel 1kg", category: "household", price: 550, emoji: "🧼", color: "#2563eb", rack: 5, slot: 0 },
  { name: "Lifebuoy Soap", category: "household", price: 130, emoji: "🧼", color: "#e11d48", rack: 5, slot: 1 },
  { name: "Head & Shoulders", category: "household", price: 690, emoji: "🧴", color: "#0891b2", rack: 5, slot: 2 },
  { name: "Rose Petal Tissue", category: "household", price: 220, emoji: "🧻", color: "#f472b6", rack: 5, slot: 3 },
  { name: "Colgate Toothpaste", category: "household", price: 280, emoji: "🪥", color: "#ef4444", rack: 5, slot: 4 },
  { name: "Dish Wash Bar", category: "household", price: 90, emoji: "🧽", color: "#22c55e", rack: 5, slot: 5 },

  // Atta, Chini & Staples (rack 6)
  { name: "Atta (Flour) 10kg", category: "staples", price: 1250, emoji: "🌾", color: "#d4a373", rack: 6, slot: 0 },
  { name: "Chini (Sugar) 1kg", category: "staples", price: 160, emoji: "🍚", color: "#f8fafc", rack: 6, slot: 1 },
  { name: "Basmati Rice 5kg", category: "staples", price: 1800, emoji: "🍚", color: "#fef9c3", rack: 6, slot: 2 },
  { name: "Daal Chana 1kg", category: "staples", price: 340, emoji: "🫘", color: "#ca8a04", rack: 6, slot: 3 },
  { name: "Daal Masoor 1kg", category: "staples", price: 380, emoji: "🫘", color: "#b91c1c", rack: 6, slot: 4 },
  { name: "Cooking Oil 5L", category: "staples", price: 2600, emoji: "🛢️", color: "#facc15", rack: 6, slot: 5 },

  // Masala & Cooking (rack 7)
  { name: "Shan Biryani Masala", category: "staples", price: 130, emoji: "🌶️", color: "#dc2626", rack: 7, slot: 0 },
  { name: "National Haldi", category: "staples", price: 90, emoji: "🟡", color: "#eab308", rack: 7, slot: 1 },
  { name: "Lal Mirch Powder", category: "staples", price: 110, emoji: "🌶️", color: "#b91c1c", rack: 7, slot: 2 },
  { name: "Namak (Salt) 800g", category: "staples", price: 60, emoji: "🧂", color: "#e2e8f0", rack: 7, slot: 3 },
  { name: "Ginger Garlic Paste", category: "staples", price: 180, emoji: "🧄", color: "#fef3c7", rack: 7, slot: 4 },
  { name: "Tomato Ketchup", category: "staples", price: 240, emoji: "🍅", color: "#dc2626", rack: 7, slot: 5 },
];
