export type GameProduct = {
  id: number;
  name: string;
  category: string;
  price: number;
  emoji: string;
  color: string;
  imageUrl: string | null;
  modelUrl: string | null;
  rack: number;
  slot: number;
};

export type ScoreRow = {
  id: number;
  name: string;
  score: number;
  items: number;
  spend: number;
  createdAt: string;
};
